package com.example.FBJV24001115synergy7indbinfoodch4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FBjv24001115Synergy7IndBinfoodCh4Application {

	public static void main(String[] args) {
		SpringApplication.run(FBjv24001115Synergy7IndBinfoodCh4Application.class, args);
	}

}
