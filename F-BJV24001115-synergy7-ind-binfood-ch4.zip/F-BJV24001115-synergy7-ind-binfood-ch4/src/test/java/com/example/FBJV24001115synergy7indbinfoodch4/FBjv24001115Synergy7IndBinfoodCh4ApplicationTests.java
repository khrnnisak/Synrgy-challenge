package com.example.FBJV24001115synergy7indbinfoodch4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FBjv24001115Synergy7IndBinfoodCh4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
